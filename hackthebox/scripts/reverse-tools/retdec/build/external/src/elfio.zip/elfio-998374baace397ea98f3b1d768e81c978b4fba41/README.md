## ELFIO

A clone of the [ELFIO](https://github.com/serge1/ELFIO) library with some bug fixes.

## Status

This repository is temporary. If possible, modifications made in this repository should be merged into the original repository. The original repository should be used where this repository is used, and this repository should be removed.

`CMakeLists.txt` should also be added to the original repository, so it is possible to use the `elfio` CMake target.

## License

Copyright (C) 2001-2011 by Serge Lamikhov-Center, licensed under the MIT license. See the `COPYING.txt` file for more details.
