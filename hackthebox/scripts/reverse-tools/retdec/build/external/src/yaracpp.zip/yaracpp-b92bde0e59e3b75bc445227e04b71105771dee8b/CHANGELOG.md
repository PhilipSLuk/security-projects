# Changelog

# dev

* Fixed build of libyara under 32b Unix-like systems ([avast-tl/yara#1](https://github.com/avast-tl/yara/pull/1)).

# v1.0.1 (2017-01-18)

* Fixed build of libyara with Visual Studio 2017 without the 2015 toolset.

# v1.0 (2017-12-12)

Initial release.
