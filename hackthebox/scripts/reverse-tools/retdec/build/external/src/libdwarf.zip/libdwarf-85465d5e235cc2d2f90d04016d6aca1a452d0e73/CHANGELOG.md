# Changelog

# dev

* Set a proper `RPATH` when installing the libraries on Linux and macOS.
* Removed the `LIBDWARF_INSTALL_TO_UNITTESTS` CMake option.
* Renamed built libraries to `libretdec-{libdwarf,libelf}.so` (similarly on Windows).

# v1.0 (2017-12-12)

Initial release.
