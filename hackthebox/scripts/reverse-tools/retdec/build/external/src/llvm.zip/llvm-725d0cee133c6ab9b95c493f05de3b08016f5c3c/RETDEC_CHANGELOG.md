# Changelog

# dev

* Fix: Build of `DynamicLibrary.cpp` with musl libc ([retdec #145](https://github.com/avast-tl/retdec/issues/145)).
* Fix: Build with the Ninja CMake generator.
* Fix: Build on Windows with VS 2017 when DIA SDK is installed.
* Fix: Build on macOS ([#1](https://github.com/avast-tl/llvm/pull/1)).

# v1.0 (2017-12-12)

Initial release.
