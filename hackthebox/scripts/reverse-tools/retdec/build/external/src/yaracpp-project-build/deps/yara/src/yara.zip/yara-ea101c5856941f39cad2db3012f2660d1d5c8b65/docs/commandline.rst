.. _command-line:

**********************************
Running YARA from the command-line
**********************************

In order to invoke YARA you’ll need two things: a file with the rules you want
to use (either in source code or compiled form) and the target to be scanned.
The target can be a file, a folder, or a process. ::

  yara [OPTIONS] RULES_FILE TARGET


Rule files can be passed directly in source code form, or can be previously
compiled with the ``yarac`` tool. You may prefer to use your rules in compiled
form if you are going to invoke YARA multiple times with the same rules. This
way you’ll save time, because for YARA it is faster to load compiled rules than
compiling the same rules over and over again.

The rules will be applied to the target specified as the last argument to YARA,
if it’s a path to a directory all the files contained in it will be scanned.
By default YARA does not attempt to scan directories recursively, but you can
use the ``-r`` option for that.

Available options are:

.. program:: yara

.. option:: -t <tag> --tag=<tag>

  Print rules tagged as <tag> and ignore the rest.

.. option:: -i <identifier> --identifier=<identifier>

  Print rules named <identifier> and ignore the rest.

.. option:: -n

  Print not satisfied rules only (negate).

.. option:: -D --print-module-data

  Print module data.

.. option:: -g --print-tags

  Print tags.

.. option:: -m --print-meta

  Print metadata.

.. option:: -s --print-strings

  Print matching strings.

.. option:: -L --print-string-length

  Print length of matching strings.

.. option:: -e --print-namespace

  Print rules' namespace.

.. option:: -p <number> --threads=<number>

  Use the specified <number> of threads to scan a directory.

.. option:: -l <number> --max-rules=<number>

  Abort scanning after matching a number of rules.

.. option:: -a <seconds> --timeout=<seconds>

  Abort scanning after a number of seconds has elapsed.

.. option:: -k <slots> --stack-size=<slots>

  Allocate a stack size of "slots" number of slots. Default: 16384. This
  will allow you to use larger rules, albeit with more memory overhead.

  .. versionadded:: 3.5.0

.. option:: -d <identifier>=<value>

  Define external variable.

.. option:: -x <module>=<file>

  Pass file's content as extra data to module.

.. option:: -r --recursive

  Recursively search for directories.

.. option:: -f --fast-scan

  Fast matching mode.

.. option:: -w --no-warnings

  Disable warnings.

.. option:: --fail-on-warnings

  Treat warnings as errors. Has no effect if used with --no-warnings.

.. option:: -v --version

  Show version information.

.. option:: -h --help

  Show help.

Here you have some examples:

* Apply rule in */foo/bar/rules* to all files in the current directory.
  Subdirectories are not scanned::

    yara /foo/bar/rules  .

* Apply rules in */foo/bar/rules* to *bazfile*. Only reports rules tagged as
  *Packer* or *Compiler*::

    yara -t Packer -t Compiler /foo/bar/rules bazfile

* Scan all files in the */foo* directory and its subdirectories::

    yara -r /foo

* Defines three external variables *mybool*, *myint* and *mystring*::

    yara -d mybool=true -d myint=5 -d mystring="my string" /foo/bar/rules bazfile

* Apply rules in */foo/bar/rules* to *bazfile* while passing the content of
  *cuckoo_json_report* to the cuckoo module::

    yara -x cuckoo=cuckoo_json_report /foo/bar/rules bazfile
