

	README-win.txt:				Jun 2004
     (schoenfr@web.de)				Oct 2004



here you find a precompiled windows binary of `npiet', an interperter
for the piet programming language and `npiet-foogol', a compiler to
translate foogol source into piet code.

simply start npiet-start.bat which launches a dos shell and try:

  npiet.exe examples/hi.png


the npiet editor `npietedit.tcl' needs Tk/Tcl to execute.


about the piet programming language please visit:

	http://www.dangermouse.net/esoteric/piet.html


and for more about th npiet interpreter please have a look at:

	http://www.bertnase.de/npiet/



have fun!


--
Sat Sep 24 15:17:29 CEST 2011

